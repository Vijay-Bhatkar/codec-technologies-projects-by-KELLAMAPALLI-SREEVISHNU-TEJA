<div class="container">
	<div class="rows">
		<div class="col-md-12">
			<div class="well">
				<div class="media">
			  <a class="pull-left" href="#">
			    <img class="media-object" src="img/bamenda.png" width="800px">
			  </a>
			</div>
			</div>
	</div>
</div>