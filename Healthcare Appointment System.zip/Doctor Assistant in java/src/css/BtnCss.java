/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package css;

/**
 *
 * @author RIfat
 */
public class BtnCss {

    public String homeActive = "-fx-border-width: 0px 0px 0px 7px;"
            + "-fx-border-color:#FF4E3C;"
            + "-fx-background-image: url(\"icon/homeRed.png\");"
            + "-fx-text-fill: #EA5444;";

    public String prescriptionActive = "-fx-border-width: 0px 0px 0px 7px;"
            + "-fx-border-color:#FF4E3C;"
            + "-fx-background-image: url(\"icon/prescriptionRed.png\");"
            + "-fx-text-fill: #EA5444;";

    public String templateActive = "-fx-border-width: 0px 0px 0px 7px;"
            + "-fx-border-color:#FF4E3C;"
            + "-fx-background-image: url(\"icon/templateRed.png\");"
            + "-fx-text-fill: #EA5444;";

    public String patientActive = "-fx-border-width: 0px 0px 0px 7px;"
            + "-fx-border-color:#FF4E3C;"
            + "-fx-background-image: url(\"icon/patientRed.png\");"
            + "-fx-text-fill: #EA5444;";

    public String drugActive = "-fx-border-width: 0px 0px 0px 7px;"
            + "-fx-border-color:#FF4E3C;"
            + "-fx-background-image: url(\"icon/drugRed.png\");"
            + "-fx-text-fill: #EA5444;";
    
     public String settingActive = "-fx-border-width: 0px 0px 0px 7px;"
            + "-fx-border-color:#FF4E3C;"
            + "-fx-background-image: url(\"icon/settingsRed.png\");"
            + "-fx-text-fill: #EA5444;";
}
